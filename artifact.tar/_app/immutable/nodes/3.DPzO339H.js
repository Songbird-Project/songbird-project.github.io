import"../chunks/DsnmJJEf.js";import"../chunks/69_IOA4Y.js";function t(o){}export{t as component};
